#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define SHMNAME "/shm_for_test_of_strace"
#define SEMNAME "/sem_for_test_of_strace"
#define NUMPROCS 32

struct shmstruct {
	int count;
	pid_t pid[NUMPROCS];
};

