#include "bar.h"

int
main(int argc, char **argv)
{
	int fd;
	struct shmstruct *ptr;
	sem_t *mutex;
	int i;
	pid_t pid;

	if ((fd = shm_open(SHMNAME, O_RDWR, 
		S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)) == -1) {
		perror("shm_open");
		exit(1);
	}

	if((ptr = mmap(NULL, sizeof(struct shmstruct), 
			PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0) )
			== MAP_FAILED) {
		perror("mmap");
		exit(1);
	}

	close(fd);


	if ((mutex = sem_open(SEMNAME, 0)) == SEM_FAILED ) {
		perror("sem_open");
		exit(1);
	}

	/* wait until all targets reach */

	while (ptr->count < NUMPROCS) {
		sleep(1);
	}

	/* check if pids are vailid */
	for (i = 0; i < NUMPROCS; i++) {
		if (ptr->pid[i] == 0) {
			fprintf(stderr, "pid[%d] is zero\n", ptr->pid[i]);
			exit(1);
		}
	}

	for (i = 0; i < NUMPROCS; i++) {
		printf("-p %d ", ptr->pid[i]);
	}
	printf("\n");

	if (sem_wait(mutex)  == -1) {
		perror("sem_wait");
		exit(1);
	}

	/* kick targets */
	ptr->count ++;

	if (sem_post(mutex)  == -1) {
		perror("sem_post");
		exit(1);
	}

	exit(0);
}
