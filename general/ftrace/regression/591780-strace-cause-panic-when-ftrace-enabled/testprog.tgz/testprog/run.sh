#!/bin/bash

i=1

./prepare

while [ $i -le 32 ]
do
        ./target &
        i=`expr $i + 1`
done

set -- `./cord`
strace -o logfile $@ >log.stdout 2>log.stderr

RET=$?

./cleanup

echo $RET > log.ret
