#include "bar.h"

int
main(int argc, char **argv)
{

	shm_unlink(SHMNAME);
	sem_unlink(SEMNAME);

	exit(0);

}


