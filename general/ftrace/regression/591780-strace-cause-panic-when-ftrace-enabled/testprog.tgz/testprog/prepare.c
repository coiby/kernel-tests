#include "bar.h"


int
main(int argc, char **argv)
{
	int fd;
	struct shmstruct *ptr;
	sem_t *mutex;

	/* clean up before allocation */
	shm_unlink(SHMNAME);
	sem_unlink(SEMNAME);

	if ((fd = shm_open(SHMNAME, O_RDWR | O_CREAT | O_EXCL, 
		S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)) == -1) {
		perror("shm_open");
		exit(1);
	}

	if (ftruncate(fd, sizeof(struct shmstruct)) == -1) {
		perror("ftruncate");
		exit(1);
	}

	if((ptr = mmap(NULL, sizeof(struct shmstruct), 
			PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0) )
			== MAP_FAILED) {
		perror("mmap");
		exit(1);
	}

	close(fd);

	if ((mutex = sem_open(SEMNAME, O_CREAT | O_EXCL, 
		S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH, 1)) == SEM_FAILED ) {
		perror("sem_open");
		exit(1);
	}

	sem_close(mutex);

	exit(0);

}


